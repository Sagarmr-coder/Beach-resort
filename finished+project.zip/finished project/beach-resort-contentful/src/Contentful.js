import { createClient } from "contentful";

export default createClient({
  space: "your space id",
  accessToken: "your access token"
});
